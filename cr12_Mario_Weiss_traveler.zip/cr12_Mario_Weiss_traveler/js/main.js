$('.menu-social-links-menue-container').addClass('navbar navbar-nav navbar-dark navbar-expand mb-auto')
$('.menu-social-links-menue-container ul').addClass('navbar-nav mr-auto mt-2 mt-lg-0')
$('.menu-social-links-menue-container a').addClass('px-2 nav-link')
$('#social-h').show();
$('#social-h2').show();